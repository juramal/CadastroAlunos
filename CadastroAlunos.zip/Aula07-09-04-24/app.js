const express = require('express')
const app = express()
const port = 3000
app.use(express.json())

//CADASTRO DE ALUNOS

let alunos = []

// Adicionar um aluno na lista
app.post('/alunos', (req, res) => {
    const { ra, nome, turma } = req.body;
    const novoAluno = { ra, nome, turma, cursos: [] };
    alunos.push(novoAluno);
    res.send(JSON.stringify(novoAluno));
});

// Adicionar um curso para o aluno
app.post('/alunos/:ra/curso', (req, res) => {
    const ra = req.params.ra;
    const curso = req.body.curso;
    const aluno = alunos.find(a => a.ra === ra);
    if (aluno) {
        aluno.cursos.push(curso);
        res.send('Curso adicionado para o aluno');
    } else {
        res.status(404).send('Aluno não encontrado');
    }
});

// Alterar os dados de um aluno através do RA
app.put('/alunos/:ra', (req, res) => {
    const ra = req.params.ra;
    const newData = req.body;
    const index = alunos.findIndex(a => a.ra === ra);
    if (index !== -1) {
        alunos[index] = { ...alunos[index], ...newData };
        res.send('Dados do aluno alterados com sucesso');
    } else {
        res.status(404).send('Aluno não encontrado');
    }
});

// Alterar o curso do aluno
app.put('/alunos/:ra/curso', (req, res) => {
    const ra = req.params.ra;
    const novoCurso = req.body.curso;
    const aluno = alunos.find(a => a.ra === ra);
    if (aluno) {
        aluno.cursos = [novoCurso];
        res.send('Curso do aluno alterado com sucesso');
    } else {
        res.status(404).send('Aluno não encontrado');
    }
});

// Remover um aluno da lista
app.delete('/alunos/:ra', (req, res) => {
    const ra = req.params.ra;
    alunos = alunos.filter(a => a.ra !== ra);
    res.send('Aluno removido com sucesso');
});

// Remover o curso do aluno
app.delete('/alunos/:ra/curso', (req, res) => {
    const ra = req.params.ra;
    const aluno = alunos.find(a => a.ra === ra);
    if (aluno) {
        aluno.cursos = [];
        res.send('Curso do aluno removido com sucesso');
    } else {
        res.status(404).send('Aluno não encontrado');
    }
});

// Listar todos os alunos (RA, Nome, Turma)
app.get('/alunos', (req, res) => {
    res.json(alunos.map(({ ra, nome, turma }) => ({ ra, nome, turma })));
});

// Listar um aluno através do RA informado (Nome, Turma, Cursos)
app.get('/alunos/:ra', (req, res) => {
    const ra = req.params.ra;
    const aluno = alunos.find(a => a.ra === ra);
    if (aluno) {
        res.json({ nome: aluno.nome, turma: aluno.turma, cursos: aluno.cursos });
    } else {
        res.status(404).send('Aluno não encontrado');
    }
});

app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});

